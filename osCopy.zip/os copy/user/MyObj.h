#ifndef __MyObj_include__
#define __MyObj_include__
class MyObj {

    public:
        int myNum;
        char myChar;
        MyObj();
        MyObj(int someNum, char someChar);
};

#endif
