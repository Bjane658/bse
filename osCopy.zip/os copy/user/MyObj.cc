#include "user/MyObj.h"


MyObj::MyObj(){
}

MyObj::MyObj(int someNum, char someChar){
    myNum = someNum;
    myChar = someChar;
}
