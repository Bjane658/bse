/*****************************************************************************
 *                                                                           *
 *                         K E Y I R Q D E M O                               *
 *                                                                           *
 *---------------------------------------------------------------------------*
 * Beschreibung:    Demo zu Interrupts.                                      *
 *                                                                           *
 * Autor:           Michael Schoettner, HHU, 26.10.2018                      *
 *****************************************************************************/

#ifndef __KeyIRQDemo_include__
#define __KeyIRQDemo_include__

void key_irq_demo();  

#endif
