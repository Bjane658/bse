
#include "kernel/Globals.h"

void textDemo();
